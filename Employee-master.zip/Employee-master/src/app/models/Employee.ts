export class EmployeeModel{

    public employeeId:number;
    public employeeName:String;
    public employeeGender:String;
    public employeeDepartment:String;
    public employeeSalary:number;

}