import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { EmployeeModel } from '../model/Employee';
import { EmployeeService } from '../service/employee.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  //to create new employee or edit it
  @Input() employee: EmployeeModel;

  // to control update button in form
  @Input() isEditing: boolean;

  @Output() edited = new EventEmitter();

  //initilize it
  constructor(private empService: EmployeeService) {
    this.employee = new EmployeeModel();
  }

  add() {
    this.empService.add(this.employee);
    this.employee = new EmployeeModel();
  }

  update()
  {
    this.isEditing = false;
    this.employee = new EmployeeModel();
    this.edited.emit();
  }
}
