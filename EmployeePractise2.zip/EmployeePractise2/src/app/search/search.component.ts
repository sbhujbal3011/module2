import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../service/employee.service';
import { EmployeeModel } from '../model/Employee';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  employeeSearched: EmployeeModel;
  constructor(private empService:EmployeeService) { 
    this.employeeSearched = new EmployeeModel();
  }

  ngOnInit() {
  }

  searchEmp(id:number)
  {
    this.employeeSearched = this.empService.searchEmp(id);
  }

}
