import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { StudentModel } from '../model/Student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  studentArr: StudentModel[];

  constructor(private routes:Router) {
    this.studentArr = [];
  }


  add(Student: StudentModel) {
    Student. studentRollNo= Math.floor(Math.random() * 100);
    this.studentArr.push(Student);
    this.routes.navigate(['/display']);
  }
  getEmployees() {
    return this.studentArr;
  }
  delete(index: number) {
    this.studentArr.splice(index, 1);
  }
  search(id: number) {
    var result = this.studentArr.find(x => x.studentRollNo == id);
    if (result == null)
      return null; //if not found
    else
      return result; //if found then store it
  }
  sortstudByName()
  {
    this.studentArr.sort((a,b)=>a.studentName.localeCompare(b.studentName.valueOf()));
    return this.studentArr;
  }

  sortstudByRollNo() {
    this.studentArr.sort((a, b) => a.studentRollNo - b.studentRollNo);
    return this.studentArr;
  }

  edit(id: number) {
    return this.studentArr.find(x => x.studentRollNo== id);
  }
}
