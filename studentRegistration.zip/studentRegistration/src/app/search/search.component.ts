import { Component, OnInit } from '@angular/core';
import { StudentService } from '../service/student.service';
import { StudentModel } from '../model/student';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  studentSearched: StudentModel;
  constructor(private studService: StudentService) { 
    this. studentSearched = new  StudentModel();
  }

  ngOnInit() {
  }

  search(id:number)
  {
    this. studentSearched = this.studService.search(id);
  }

}

