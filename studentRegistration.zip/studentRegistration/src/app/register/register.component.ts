import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { StudentModel } from '../model/Student';
import { StudentService } from '../service/student.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent  {

   //to create new student or edit it
   @Input() student: StudentModel;

   // to control update button in form
   @Input() isEditing: boolean;
 
   @Output() edited = new EventEmitter();
 
   //initilize it
   constructor(private StudService: StudentService) {
     this.student = new StudentModel();
   }
 
   add() {
    this.StudService.add(this.student);
     this.student = new StudentModel();
   }
 
   update()
   {
     this.isEditing = false;
     this.student = new StudentModel();
     this.edited.emit();
   }
 }
 
