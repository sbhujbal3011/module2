import { Component, OnInit } from '@angular/core';
import { StudentService } from '../service/student.service';
import { StudentModel } from '../model/Student';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  studentArr:StudentModel[];
  studentToEdit:StudentModel;
  isEditing:boolean;

  constructor(private studService:StudentService) { 
    this.studentArr = [];
    this.studentToEdit = new StudentModel;
  }

  ngOnInit() {
    this. studentArr = this.studService.getEmployees();
  }

  sortstudByName()
  {
    this.studService.sortstudByName();
  }

  sortstudByRollNo()
  {
    this.studService.sortstudByRollNo();
  }

  delete(index: number) {
   this.studService.delete(index);
  }

  edit(id:number)
  {
    this.isEditing = true;
    this.studentToEdit = this.studService.edit(id);
  }

}
