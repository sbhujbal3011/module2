export class StudentModel {

    public studentName: String;
    public studentRollNo: number;
    public studentGender: String;
    public studentDepartment: String;
    public studentPercentage: number;
}