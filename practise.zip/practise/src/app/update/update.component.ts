import { Component, OnInit } from '@angular/core';
import { ListModel } from '../models/list';
import { ActivatedRoute, Router } from '@angular/router';
import { ListService } from '../services/list.service';
import {filter} from 'rxjs/operators';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  updatedList: ListModel;
  paramIndex;
  constructor(private route: ActivatedRoute, private router: Router, private listService: ListService) {
    this. updatedList = new ListModel();
  }

  ngOnInit() {
    if (window.location.search !== '') {
      // take id from route query param and prefill data of particular task
      this.route.queryParams.pipe(
      filter(params => params.id))
      .subscribe(params => {
      console.log(params.id);
      this.paramIndex = params.id;
      this. updatedList = this.listService.getDetailsOf(this.paramIndex);
      });
    }
  }
  updateList() {
    // send index of task and updated details
    this.listService.edit(this.paramIndex, this. updatedList);
  }
}

