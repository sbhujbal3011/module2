export class ListModel {
    name: String;
    city: String;
    phone: number;

}
