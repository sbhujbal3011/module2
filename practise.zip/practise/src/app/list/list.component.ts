import { Component, OnInit } from '@angular/core';
import { ListModel } from '../models/list';
import { Router } from '@angular/router';
import { ListService } from '../services/list.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  allList: ListModel[];
  confirmationStatus;
  constructor(private router: Router, private listService: ListService) {
    this.allList = [];
  }

  ngOnInit() {
    this.allList = this.listService.display();
  }
  add() {
    // navigate to home page on click of Go to Home button
    this.router.navigate(['/add']);
  }
  deleteList(index: number) {
    // ask user confirmation on delete
    this.confirmationStatus = confirm('Do you want to delete the task?');
    if (this.confirmationStatus) {
      this.listService.delete(index);
    }
  }
  editList(index: number) {
    this.listService.editList(index);
  }
}


