import { Injectable } from '@angular/core';
import { ListModel } from '../models/list';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ListService {

  listArray: ListModel[];
  constructor(private router: Router) {
    this.listArray = [];
  }
  add(list:  ListModel) {
    // add task to array
    this.listArray.push(list);
    this.router.navigate(['/list']);
    console.log(this.listArray);
  }
  display() {
    return this.listArray;
  }
  delete(index: number) {
    // delete a particular task
    this.listArray.splice(index, 1);
  }
  editList(index: number) {
    // add id of task through route to prefill and edit particular task
  this.router.navigate(['/edit'], { queryParams: { id: index }});
  }
  getDetailsOf(index) {
    // get details of particular task
    return this.listArray[index];
  }
  edit(index: number, updatedList:  ListModel) {
    // update edited task details to array
    this.listArray[index] = updatedList;
    this.router.navigate(['/list']);
  }
}
