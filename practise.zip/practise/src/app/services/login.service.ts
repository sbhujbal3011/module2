import { Injectable } from '@angular/core';
import { LoginModel } from '../models/loginModel';

@Injectable({
  providedIn: 'root'
})

  export class LoginService {
    correctCredentials: LoginModel;
    constructor() {
      // sets default correct credentials
      this.correctCredentials = new LoginModel();
      this.correctCredentials.email = 'admin@gmail.com';
      this.correctCredentials.password = '123456';
    }
  }


