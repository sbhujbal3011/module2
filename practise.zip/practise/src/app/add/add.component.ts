import { Component, OnInit } from '@angular/core';
import { ListModel } from '../models/list';
import { Router } from '@angular/router';
import { ListService } from '../services/list.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  newlist: ListModel;
  constructor(private router: Router, private listService: ListService) {
      this.newlist = new ListModel();
      // status is set to default incomplete
     // this.newlist.taskStatus = 'Incompelte';
   }

  ngOnInit() {
  }
  goBack() {
    this.router.navigate(['/list']);
  }
  addlist() {
    this. listService.add(this.newlist);
  }
}
