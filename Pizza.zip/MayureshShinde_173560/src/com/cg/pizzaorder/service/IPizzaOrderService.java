package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.InvalidInputException;
import com.cg.pizzaorder.exception.PizzaException;

public interface IPizzaOrderService {
	String ENTRY = "[1-3]{1}";
	String USER_NAME_PATTERN = "[A-Za-z]{1,25}";
	String ADDRESS_PATTERN = "[A-Za-z]{1,25}";
	String MOBILE_PATTERN = "[0-9]{10}";
	String ORDERID="[0-9]{1,3}";

	boolean validateEntry(String choice) throws InvalidInputException;

	boolean validateMobile(String mobile) throws InvalidInputException;

	boolean validateUserName(String userName) throws InvalidInputException;

	boolean validateAddress(String address) throws InvalidInputException;

	int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException;

	PizzaOrder getorderdetails(int orderId) throws PizzaException;

	boolean validateOrderId(String id) throws InvalidInputException;
}
