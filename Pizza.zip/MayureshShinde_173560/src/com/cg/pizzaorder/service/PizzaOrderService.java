package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.InvalidInputException;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {
	PizzaOrderDAO dao = new PizzaOrderDAO();

	public boolean validateEntry(String choice) throws InvalidInputException {
		if (choice.matches(ENTRY))
			return true;
		else
			throw new InvalidInputException("Enter valid choice i.e 1 to 3");
	}

	@Override
	public boolean validateMobile(String mobile) throws InvalidInputException {
		if (mobile.matches(MOBILE_PATTERN))
			return true;
		else
			throw new InvalidInputException(
					"Enter valid Mobile no eg. 9167968584");
	}

	@Override
	public boolean validateUserName(String userName)
			throws InvalidInputException {
		if (userName.matches(USER_NAME_PATTERN))
			return true;
		else
			throw new InvalidInputException("Enter valid name eg. John/john");
	}
	@Override
	public boolean validateOrderId(String id)
			throws InvalidInputException {
		if (id.matches(ORDERID))
			return true;
		else
			throw new InvalidInputException("Enter valid id eg. 786");
	}
	@Override
	public boolean validateAddress(String address) throws InvalidInputException {
		if (address.matches(ADDRESS_PATTERN))
			return true;
		else
			throw new InvalidInputException("Enter valid Address eg. Mumbai");
	}

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws PizzaException {
		return dao.placeOrder(customer, pizza);

	}

	@Override
	public PizzaOrder getorderdetails(int orderId) throws PizzaException {
		return dao.getorderdetails(orderId);
	}
}
