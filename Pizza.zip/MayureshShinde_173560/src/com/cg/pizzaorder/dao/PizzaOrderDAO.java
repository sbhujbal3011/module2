package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderDAO implements IPizzaOrderDAO {
	private Map<Integer, PizzaOrder> pizzaEntry = null;
	private Map<Integer, Customer> customerEntry = null;
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws PizzaException {
		int custId = (int) (Math.random() * 1000);
		int orderId = (int) (Math.random() * 1000);
		if (pizza.getTotalPrice() != 0) {
			pizzaEntry = new HashMap<Integer, PizzaOrder>();
			customerEntry = new HashMap<Integer, Customer>();
			customer.setCustomerId(custId);
			pizza.setCustomerId(custId);
			pizza.setOrderId(orderId);
			customerEntry.put(customer.getCustomerId(), customer);
			pizzaEntry.put(pizza.getOrderId(), pizza);

			return orderId;
		}
		throw new PizzaException("Enter proper details");

	}

	@Override
	public PizzaOrder getorderdetails(int orderId) throws PizzaException {
		if (pizzaEntry != null) {
			PizzaOrder pizza = pizzaEntry.get(orderId);
			if(pizza!=null)
			return pizza;
			else
				throw new PizzaException("Order cart is Empty");
		} else
			throw new PizzaException("Order cart is Empty");
	}

}
