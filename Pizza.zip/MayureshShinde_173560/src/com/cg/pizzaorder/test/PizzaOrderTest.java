package com.cg.pizzaorder.test;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderTest {
	PizzaOrderDAO dao = null;
	Map<Integer, PizzaOrder> pizzaEntry = null;

	@Before
	public void setUp() throws Exception {
		new HashMap<Integer, PizzaOrder>();
		dao = new PizzaOrderDAO();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
		Map<Integer, PizzaOrder> pizzaEntry = null;
	}

	@Test(expected = PizzaException.class)
	public void testInvalidPlaceOrder() throws PizzaException{
		dao.placeOrder(new Customer(), new PizzaOrder());
	}
	@Test
	public void testValidPlaceOrder() throws PizzaException {
		Customer cust = new Customer();
		PizzaOrder piz = new PizzaOrder();
		piz.setTotalPrice(400);
		Assert.assertNotNull(dao.placeOrder(cust, piz));
		
	}

	@Test
	public void testValidOrderDetails() throws PizzaException {
		Customer cust = new Customer();
		PizzaOrder piz = new PizzaOrder();
		piz.setTotalPrice(400);
		dao.placeOrder(cust, piz);
		dao.getorderdetails(piz.getOrderId());
	}

	@Test(expected = PizzaException.class)
	public void testInvalidOrderDetails() throws PizzaException {

		dao.getorderdetails(1000);
	}
}
