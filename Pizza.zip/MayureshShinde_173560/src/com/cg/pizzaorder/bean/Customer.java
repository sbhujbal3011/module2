package com.cg.pizzaorder.bean;

public class Customer {
	private int customerId;
	private String custname;
	private String address;
	private String phone;

	// generating getter setters
	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustname() {
		return custname;
	}

	public void setCustname(String custname) {
		this.custname = custname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Customer() {
	}

	public Customer(String custname, String address, String phone) {
		this.custname = custname;
		this.address = address;
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "Customer Id : " + customerId + "\nCustomer Name : " + custname
				+ "\nAddress : " + address + "\nPhone=" + phone;
	}

}
