package com.cg.Employee.util;
import java.util.HashMap;
import java.util.Map;

import com.cg.Employee.bean.employee;


public class Util {

	private static Map<Integer,employee> EmployeeEntries = new HashMap<Integer,employee>();

	public static Map<Integer,employee>getEmployeeEntries(){
		EmployeeEntries.put(101, new employee(101,12000,"Sony Xperia","account"));
		EmployeeEntries.put(102, new employee(102,10000,"sony","clerk"));
		EmployeeEntries.put(103, new employee(103,23000,"Iphone 3","manager"));
		EmployeeEntries.put(104, new employee(104,10000,"Nokia Note 2322","fresher"));
		
		return EmployeeEntries;
		
	}

}
