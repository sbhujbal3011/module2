package com.cg.Employee.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.Employee.bean.employee;
import com.cg.Employee.ui.EmployeeException;
import com.cg.Employee.util.Util;


public class EmployeeDao implements IEmployeeDao {
	
	Map<Integer, employee> map = new HashMap<Integer, employee>(
			Util.getEmployeeEntries());
	
	ArrayList<employee> set = new ArrayList<employee>(map.values());

	@Override
	public List<employee> getEmployeeList() {

		List<employee> employee = new ArrayList<>();
		for (employee Employee : set) {
			employee.add(Employee);
		}
		return employee;
	}

	@Override
	public List<employee> SortList(int criteria) {
		
		if (criteria == 1)
			// Collections.sort(set, compareN);
			Collections.sort(set,
					(obj1, obj2) -> obj1.getName().compareTo(obj2.getName()));
		//set=set.stream().sort((obj1, obj2) -> obj1.getName().compareTo(obj2.getName())).collect(Collectors.toList());
		else if (criteria == 2)
			// Collections.sort(set, comparePrice);
			Collections.sort(set,(obj1, obj2) -> obj1.getId()-obj2.getId());
					
					
		else if (criteria == 3)
			// Collections.sort(set, compareQuant);
			Collections.sort(set,(obj1,obj2) -> obj1.getDept().compareTo(obj2.getDept()) );
		return set;
	}

	@Override
	public void deleteEmpoloyee(int id) throws EmployeeException{ 
		set.remove(new employee(id, 0 ,null,null));
		if (Util.getEmployeeEntries().containsKey(id)) {
			System.out.println("hello");
		} else { 
			throw new EmployeeException("invalid id");
		}

	}
}
