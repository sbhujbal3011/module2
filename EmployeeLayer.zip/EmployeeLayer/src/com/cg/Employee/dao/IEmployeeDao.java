package com.cg.Employee.dao;

import java.util.List;

import com.cg.Employee.bean.employee;
import com.cg.Employee.ui.EmployeeException;



public interface IEmployeeDao {
	
	
	public List<employee>getEmployeeList();
	void deleteEmpoloyee(int mobcode) throws EmployeeException ;
	public List<employee>SortList(int criteria);

}
