package com.cg.Employee.bean;

import java.util.Comparator;

public class employee implements Comparator<employee>{
	
	private int id;
	private double salary;
	private String name;
	private String dept;
	
	public employee(int id, double salary, String name, String dept) {
		super();
		this.id = id;
		this.salary = salary;
		this.name = name;
		this.dept = dept;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof employee)
		{
			return ((employee)obj).id==this.id;
		}
		return false;
	
	}
	@Override
	public int compare(employee arg0, employee arg1) {
		return arg0.getId() - arg1.getId();

	}
	@Override
	public String toString() {
		return "employee [id=" + id + ", salary=" + salary + ", name=" + name
				+ ", dept=" + dept + "]";
	}
}

