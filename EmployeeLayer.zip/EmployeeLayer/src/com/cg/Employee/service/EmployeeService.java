package com.cg.Employee.service;

import java.util.List;

import com.cg.Employee.bean.employee;
import com.cg.Employee.dao.EmployeeDao;
import com.cg.Employee.ui.EmployeeException;

public class EmployeeService implements IEmployeeService {

	EmployeeDao dao = new EmployeeDao();

	@Override
	public List<employee> getEmployeeList() {
		return dao.getEmployeeList();

	}

	@Override
	public void deleteEmployee(int id) throws EmployeeException {
		dao.deleteEmpoloyee(id);
	}

	@Override
	public List<employee> SortList(int criteria) {
		return dao.SortList(criteria);
	}

}
