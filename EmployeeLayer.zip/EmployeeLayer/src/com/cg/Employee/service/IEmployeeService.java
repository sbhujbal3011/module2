package com.cg.Employee.service;

import java.util.List;

import com.cg.Employee.bean.employee;
import com.cg.Employee.ui.EmployeeException;

public interface IEmployeeService {
	
	List<employee>getEmployeeList();
	void deleteEmployee(int id) throws EmployeeException ;
	public List<employee>SortList(int criteria);


}
