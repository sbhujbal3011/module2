package com.cg.Employee.ui;

import java.security.Provider.Service;
import java.util.List;
import java.util.Scanner;

import com.cg.Employee.bean.employee;
import com.cg.Employee.service.EmployeeService;

public class Main {
	public static void main(String[] args) throws EmployeeException {

		String choice;
		int criteria;
		int id = 0;
		Scanner scan = new Scanner(System.in);

		EmployeeService service = new EmployeeService();
		while (true) {
			while (true) {
				List<employee> arr = (List<employee>) service.getEmployeeList();
				for (employee Employee : arr) {
					System.out.println(Employee + "\n");
				}
				System.out.println("What operation do you want to perform ?\n"
						+ "1.Sorting\n" + "2.Delete\n" + "3.Exit");
				System.out.println("Select a choice");
				choice = scan.next();
				if (choice.equals("1")) {
					System.out.println("Select sorting criteria\n"
							+ "1.  name\n" + "2. salary\n" + "3 dept");
					criteria = scan.nextInt();
					System.out.println("The sorted list is \n"
							+ service.SortList(criteria));
					break;
				} else if (choice.equals("2")) {
					System.out.println("Please enter the  Id.");
					id = scan.nextInt();

					try {
						service.deleteEmployee(id);
					} catch (EmployeeException e) {
						e.printStackTrace();
					}
					System.out.println("\nDeleted Successfully");
					break;
				} else if (choice.equals("3")) {
					System.exit(0);

				}

			}
		}
	}
}
