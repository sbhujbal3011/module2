package com.cg.Employee.ui;

public class EmployeeException extends Exception {

	public EmployeeException (String arg0) {
		super(arg0);
		
	}
	
	
}
