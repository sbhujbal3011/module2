package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;
import java.util.stream.Collectors;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.util.CompareName;
import com.cg.mobshop.util.SortPrice;
import com.cg.mobshop.util.SortQuant;
import com.cg.mobshop.util.Util;


public class MobileDAOImpl implements MobileDAO {
	//Map to store the values from utilities.
	Map<Integer,Mobiles> map= new HashMap<Integer, Mobiles>(Util.getMobileEntries());
	//Created a list to store the values of the Map.
//private static List<Mobiles> mobileList = map.values().stream().collect(Collectors.toList());
	 ArrayList<Mobiles> set = new ArrayList<>(map.values());
	
	CompareName compareN = new CompareName();
	SortPrice comparePrice = new SortPrice();
	SortQuant compareQuant = new SortQuant();
	
	
	@Override
	public List<Mobiles> getMobileList() {
		List<Mobiles> mobile = new ArrayList<>();
		for (Mobiles mobiles : set) {
			mobile.add(mobiles);
		}
		return mobile;
		
	}

	@Override
	public Mobiles deleteMobile(int mobcode) {
		Iterator<Mobiles> setIterator = set.iterator();
		while(setIterator.hasNext()){
			Mobiles element = setIterator.next();
			if(mobcode==element.getMobileId())
				setIterator.remove();	
			
		}
//		for (Mobiles mobiles : set) {
//			if(mobiles.equals(new Mobiles(mobcode,null,0,0)))
//			{
//				int i=set.indexOf(mobiles);
//				set.remove(i);
//			}
//		}
////		for (Mobiles mobiles : set) {
////			System.out.println(mobiles);
////		}
		return null;
		
		
	}
	
			
			
	
	

	@Override
	public List<Mobiles> SortList(int criteria) {
		if(criteria==1)
		 Collections.sort(set, compareN);
		else if(criteria==2)
		Collections.sort(set, comparePrice);
		else if(criteria==3)
			Collections.sort(set, compareQuant);
		return set;
	}

}
