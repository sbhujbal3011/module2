package com.cg.mobshop.ui;

import java.util.List;
import java.util.Scanner;

import javax.xml.ws.Service;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.MobileServiceImpl;

public class MainUI {
public static void main(String[] args) {
	
	String choice;
	int criteria;
	int id;
	int mobcode=0 ;
	Scanner scan = new Scanner(System.in);
	System.out.println("Welocme to Mobile Shopee");
	MobileServiceImpl service = new MobileServiceImpl();
	while(true){
		while(true){
	List<Mobiles> arr=(List<Mobiles>) service.getMobileList();
	for (Mobiles mob : arr) {
		System.out.println(mob+ "\n");
	}
	System.out.println("What operation do you want to perform ?\n"
			+ "1.Sorting\n"
			+ "2.Delete\n"
			+ "3.Exit");
	System.out.println("Select a choice");
	choice = scan.next();
	if(choice.equals("1")){
		System.out.println("Select sorting criteria\n"
				+ "1. Mobile name\n"
				+ "2. Mobile Price\n"
				+ "3. Mobile Quantity");
		criteria = scan.nextInt();	
		System.out.println("The sorted list is \n"+ service.SortList(criteria));
		break;
	}else if(choice.equals("2")){
		System.out.println("Please enter the mobile Id.");
		mobcode= scan.nextInt();
//		if(id==101)
//			mobcode=101;
//		else if(id==102)
//			mobcode=102;
//		else if(id==103)
//			mobcode=103;
//		else if(id==104)
//			mobcode=104;
			
		Mobiles mob=service.deleteMobile(mobcode);
		System.out.println(mob);
		System.out.println("After deleting\n"+ service.getMobileList());
		break;
	}else if(choice.equals("3")){
		System.exit(0);
	}
	
}
}
}
}