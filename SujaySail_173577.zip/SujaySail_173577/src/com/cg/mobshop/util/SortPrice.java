package com.cg.mobshop.util;

import java.util.Comparator;

import com.cg.mobshop.dto.Mobiles;

public class SortPrice implements Comparator<Mobiles>{

	@Override
	public int compare(Mobiles m1, Mobiles m2) {
		
		return (int) (m1.getPrice()-m2.getPrice());
	}

}
