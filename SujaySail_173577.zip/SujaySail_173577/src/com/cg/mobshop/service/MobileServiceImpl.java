package com.cg.mobshop.service;

import java.util.List;

import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;

public class MobileServiceImpl implements MobileService {
	MobileDAOImpl dao = new MobileDAOImpl();
	@Override
	public List<Mobiles> getMobileList() {
		
		return dao.getMobileList();
	}

	@Override
	public Mobiles deleteMobile(int mobcode) {
		return dao.deleteMobile(mobcode);
		
	}

	@Override
	public List<Mobiles> SortList(int criteria) {
		return dao.SortList(criteria);
		
	}

}
