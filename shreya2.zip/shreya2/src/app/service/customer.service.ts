import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerModel } from '../model/Customer';

@Injectable({
  providedIn: 'root'
})
export class customerService {
  customerArr: CustomerModel[];

  constructor(private routes:Router) {
    this.customerArr = [];
  }
  add(customer: CustomerModel) {
    customer. customerId= Math.floor(Math.random() * 100);
    this.customerArr.push(customer);
    this.routes.navigate(['/display']);
  }
  getCustomer() {
    return this.customerArr;
  }
  search(id: number) {
    var result = this.customerArr.find(x => x.customerId == id);
    if (result == null)
      return null; //if not found
    else
      return result; //if found then store it
  }
  sortcustByName()
  {
    this.customerArr.sort((a,b)=>a.customerName.localeCompare(b.customerName.valueOf()));
    return this.customerArr;
  }

  sortBycustId() {
    this.customerArr.sort((a, b) => a.customerId - b.customerId);
    return this.customerArr;
  }

  


}
