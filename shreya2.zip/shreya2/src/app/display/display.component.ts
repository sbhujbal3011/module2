import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../model/Customer';
import { customerService } from '../service/customer.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  customerArr:CustomerModel[];
  customerToEdit:CustomerModel;
  isEditing:boolean;

  constructor(private custService:customerService) { 
    this.customerArr = [];
    this.customerToEdit = new CustomerModel;
  }

  ngOnInit() {
    this. customerArr = this.custService.getCustomer();
  }
  sortcustByName()
  {
    this.custService.sortcustByName();
  }

  sortcustBycustId()
  {
    this.custService.sortBycustId();
  }

  
}