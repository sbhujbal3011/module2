import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../model/Customer';
import { customerService } from '../service/customer.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  customerSearched: CustomerModel;
  constructor(private custService:customerService) { 
    this. customerSearched = new  CustomerModel();
  }

  ngOnInit() {
  }

  search(id:number)
  {
    this. customerSearched = this.custService.search(id);
  }

}

