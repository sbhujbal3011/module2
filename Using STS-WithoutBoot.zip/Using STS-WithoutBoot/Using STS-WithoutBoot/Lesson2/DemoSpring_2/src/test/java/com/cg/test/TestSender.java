package com.cg.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ioc.Producer;

public class TestSender {
	
	@Test
	public void testProcess() {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("sender.xml");
		Producer p=(Producer)ctx.getBean("prod");
		
		p.process("sms", "9820102030", "hello there");
		p.process("mail", "shreya@gmail.com", "Hey There");
		p.process("watsapp", "shreya", "hi");
	}

}
