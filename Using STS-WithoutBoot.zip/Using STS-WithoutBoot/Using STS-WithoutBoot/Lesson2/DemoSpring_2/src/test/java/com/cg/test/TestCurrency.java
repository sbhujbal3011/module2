package com.cg.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.intro.CurrencyConverter;
import com.cg.ioc.Client;

public class TestCurrency {
	@Test
	public void testCurrency() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("currencyConverter.xml");
		CurrencyConverter c1 = (Client) ctx.getBean(Client.class);
		Client c2 = (Client) ctx.getBean(Client.class);

		assertEquals(c1, c2);
	}
		
	}
	

}
