package com.cg.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ioc.Hello;

public class TestHello {

	@Test
	public void testGetObject() {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("Hello.xml");
		Hello h=(Hello)ctx.getBean("hi");
		assertNotNull("null object", h);
		System.out.println(h.getGreeting());

	}

}
