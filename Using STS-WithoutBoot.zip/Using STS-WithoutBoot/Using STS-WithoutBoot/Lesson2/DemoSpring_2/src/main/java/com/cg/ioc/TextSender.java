/**
 * 
 */
package com.cg.ioc;

/**
 * @author sbhujbal
 *
 */
public class TextSender implements Sender {

	/* (non-Javadoc)
	 * @see com.cg.ioc.Sender#send(java.lang.String, java.lang.String)
	 */
	public TextSender() {
		System.out.println("Text msg is redy");
	}
	public void send(String to, String msg) {
		System.out.println("Text:"+msg+"sent to"+to);

	}

}
