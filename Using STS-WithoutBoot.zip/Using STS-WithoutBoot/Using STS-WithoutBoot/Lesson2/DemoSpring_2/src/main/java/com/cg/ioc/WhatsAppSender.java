/**
 * 
 */
package com.cg.ioc;

/**
 * @author sbhujbal
 *
 */
public class WhatsAppSender implements Sender {

	/* (non-Javadoc)
	 * @see com.cg.ioc.Sender#send(java.lang.String, java.lang.String)
	 */
	public WhatsAppSender() {
		System.out.println("Whatsapp msg is ready");
	}
	public void send(String to, String msg) {
		System.out.println("Whatsapp msg :"+msg+"sent to"+to);

	}

}
