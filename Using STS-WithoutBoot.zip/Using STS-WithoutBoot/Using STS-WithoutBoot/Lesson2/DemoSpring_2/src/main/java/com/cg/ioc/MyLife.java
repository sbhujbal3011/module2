package com.cg.ioc;

public class MyLife {
	public void MyLife() {
		System.out.println("Initialising");
	}

	public void born() {

		System.out.println("Ready for action");
	}

	public void die() {
		System.out.println("system crashed");
	}
}
