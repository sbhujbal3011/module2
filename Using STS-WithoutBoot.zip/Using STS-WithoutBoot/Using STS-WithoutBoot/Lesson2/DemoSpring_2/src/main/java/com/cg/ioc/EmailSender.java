/**
 * 
 */
package com.cg.ioc;

/**
 * @author sbhujbal
 *
 */
public class EmailSender implements Sender {
	public EmailSender() {
		System.out.println("Emailt msg is ready");
	}
	
	public void send(String to, String msg) {
		System.out.println("Email:"+msg+"sent to"+to);

	}
}
