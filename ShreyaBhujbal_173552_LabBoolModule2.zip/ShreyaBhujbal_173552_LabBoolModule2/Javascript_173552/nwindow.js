function newwindow(){
	var Width=document.getElementById("Width").value;
	var Height=document.getElementById("Height").value;
	
	var Left=document.getElementById("Left").value;
	var Top=document.getElementById("Top").value;
	
	window.open('Lab5b.html','','width='+Width+',height='+Height+',top='+Top+',left='+Left);
	
}


/**
 * 
 */