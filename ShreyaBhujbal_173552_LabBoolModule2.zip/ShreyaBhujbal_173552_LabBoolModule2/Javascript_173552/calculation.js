

function calcPayment() {
	
			var princi=Number(document.getElementById("loan").value);	
			var rate=Number(document.getElementById("rate").value);
			var n=Number(document.getElementById("time").value);
			
			if (n>15 || n<7) {
				alert("Period cannot be less than 7 Years or more than 15 Years");
			}else{
			rate=rate/(12*100);
			n=n*12;

			var interest=(princi*rate*Math.pow((1+rate),n)/(Math.pow((1+rate),n)-1));
				
			totalamount=(princi+interest);
			monthlyamount=(totalamount/n);

			document.getElementById("interest").value=Math.round(interest);
			document.getElementById("monthly").value=Math.round(monthlyamount);
			document.getElementById("total").value=Math.round(totalamount);
		}

		}