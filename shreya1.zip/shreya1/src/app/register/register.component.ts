import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { customerModel } from '../model/Customer';
import { customerService } from '../service/customer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent  {

  //to create new student or edit it
  @Input() customer: customerModel;

  // to control update button in form
  @Input() isEditing: boolean;

  @Output() edited = new EventEmitter();

  //initilize it
  constructor(private custService: customerService) {
    this.customer = new customerModel();
  }

  add() {
   this.custService.add(this.customer);
    this.customer = new customerModel();
  }

  update()
  {
    this.isEditing = false;
    this.customer = new customerModel();
    this.edited.emit();
  }
}

