import { Component, OnInit } from '@angular/core';
import { customerModel } from '../model/Customer';
import { customerService } from '../service/customer.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  customerArr:customerModel[];
  customerToEdit:customerModel;
  isEditing:boolean;

  constructor(private custService:customerService) { 
    this.customerArr = [];
    this.customerToEdit = new customerModel;
  }

  ngOnInit() {
    this. customerArr = this.custService.getCustomer();
  }
  delete(index: number) {
    this.custService.delete(index);
   }
 
   edit(id:number)
   {
     this.isEditing = true;
     this.customerToEdit = this.custService.edit(id);
   }
}