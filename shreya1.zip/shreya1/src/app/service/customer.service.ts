import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { customerModel } from '../model/Customer';

@Injectable({
  providedIn: 'root'
})
export class customerService {
  customerArr: customerModel[];

  constructor(private routes:Router) {
    this.customerArr = [];
  }
  add(customer: customerModel) {
    customer. customerId= Math.floor(Math.random() * 100);
    this.customerArr.push(customer);
    this.routes.navigate(['/display']);
  }
  getCustomer() {
    return this.customerArr;
  }

  delete(index: number) {
    this.customerArr.splice(index, 1);
  }

  edit(id: number) {
    return this.customerArr.find(x => x.customerId== id);
  }



}
