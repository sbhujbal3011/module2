export class customerModel {

    public customerName: String;
    public customerId: number;
    public customerGender: String;
    public customerAddress: String;
    public customerPhone: number;
}