import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DisplayComponent } from './display/display.component';
import { RegisterComponent } from './register/register.component';
import { customerService } from './service/customer.service';

@NgModule({
  declarations: [
    AppComponent,
    DisplayComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [customerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
