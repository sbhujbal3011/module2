package Service;

import Bean.Customer;
import Bean.IcecreamOrder;

public interface ServiceInterface {

	int IcecreamOrder1(Customer customer, IcecreamOrder order);

	IcecreamOrder getOrderDetails(int OrderId);

}
