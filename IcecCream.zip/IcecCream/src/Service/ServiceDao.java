package Service;

import Bean.Customer;
import Bean.IcecreamOrder;
import Dao.IceCreamDao;
import Dao.IcecreamDaoInterface;


public class ServiceDao implements ServiceInterface {
	IcecreamDaoInterface icecream=new IceCreamDao();

	@Override
	public int IcecreamOrder1(Customer customer, IcecreamOrder order) {
		
		return icecream.IcecreamOrder1(customer, order);
	}

	@Override
	public IcecreamOrder getOrderDetails(int OrderId) {
		return icecream.getOrderDetails(OrderId);
		
	}

	

	



}
