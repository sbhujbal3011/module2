package UI;

import java.util.Scanner;

import Bean.Customer;
import Bean.IcecreamOrder;
import Service.ServiceDao;
import Service.ServiceInterface;

public class Main {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		ServiceInterface service = new ServiceDao();
		Customer customer = new Customer();
		IcecreamOrder order = new IcecreamOrder();

		int option;
		String name;
		String address;
		String phone;
		int ch;
		int OrderId;

		System.out.println("Welcome to Naturals");
		System.out.println("select one option from following:");
		while (true) {
			System.out.println("1. Place order "
					+ "2.\nDisplay Order "
					+ "3.\nExit");
			option = sc.nextInt();
			
			switch (option) {
			case 1:
				System.out.println("Enter your name: ");
				name = sc.next();
				System.out.println("Enter your address: ");
				address = sc.next();
				System.out.println("Enter your 10 digit mobile no: ");
				phone = sc.next();
				customer.setName(name);
				customer.setAddress(address);
				customer.setPhone(phone);
				System.out.println("Select Flavors..");
				System.out.println("Flavors \tPrice");
				System.out.println("1.Vanila\t30");
				System.out.println("2.Strwaberry\t50");
				System.out.println("3.chocolate\t70");
				System.out.println("4.Butterscotch\t85");
				ch = sc.nextInt();
				switch (ch) {
				case 1:
					order.setFlavor("Vanila");
					order.setTotalPrice(50+30);
//					order.setotalPrice(50 + 30);

					break;
				case 2:
					order.setFlavor("Strwaberry");
					order.setTotalPrice(50 + 50);

					break;
				case 3:
					order.setFlavor("chocolate");
					order.setTotalPrice(50 + 70);

					break;
				case 4:
					order.setFlavor("Butterscotch");
					order.setTotalPrice(50 + 85);

					break;

				default:
					System.out.println("Invalid input");
					break;
				}
				OrderId = service.IcecreamOrder1(customer, order);
				System.out.println("Icecream Order palced with order id: "
						+ OrderId);
				System.out.println("Order Date: " + order.getLd());
				System.out.println("Your Bill:" + order.getTotalPrice());
				break;
			case 2:
				System.out.println("Enter your OrderId: ");
				OrderId = sc.nextInt();
				
					service.getOrderDetails(OrderId);
				
				break;
			case 3:
				System.out.println("thank you for your time");
				System.exit(0);



			}
		}
	}
}