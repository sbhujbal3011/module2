package Bean;

import java.time.LocalDate;

public class IcecreamOrder {
	private int OrderId,customerId;
	private double totalPrice;
	private String Flavor;
	@Override
	public String toString() {
		return "IcecreamOrder [OrderId=" + OrderId + ", customerId="
				+ customerId + ", totalPrice=" + totalPrice + ", Flavor="
				+ Flavor + ", ld=" + ld + "]";
	}
	public IcecreamOrder() {
		super();
		// TODO Auto-generated constructor stub
	}
	public IcecreamOrder(int orderId, int customerId, double totalPrice,
			String flavor, LocalDate ld) {
		super();
		OrderId = orderId;
		this.customerId = customerId;
		this.totalPrice = totalPrice;
		Flavor = flavor;
		this.ld = ld;
	}
	public int getOrderId() {
		return OrderId;
	}
	public void setOrderId(int orderId) {
		OrderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getFlavor() {
		return Flavor;
	}
	public void setFlavor(String flavor) {
		Flavor = flavor;
	}
	public LocalDate getLd() {
		return ld;
	}
	public void setLd(LocalDate ld) {
		this.ld = ld;
	}
	private LocalDate ld;

}
