package Dao;

import Bean.Customer;
import Bean.IcecreamOrder;

public interface IcecreamDaoInterface {

	int IcecreamOrder1(Customer customer, IcecreamOrder order);

	IcecreamOrder getOrderDetails(int OrderId);

}
