package Dao;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import Bean.Customer;
import Bean.IcecreamOrder;



public class IceCreamDao implements IcecreamDaoInterface {
	
	Map<Integer, Customer> custEntry=new HashMap<Integer, Customer>();
	Map<Integer, IcecreamOrder> IcecreamEntry=new HashMap<Integer,IcecreamOrder >();

	@Override
	public int IcecreamOrder1(Customer customer, IcecreamOrder order) {
		int custId=(int) (Math.random()*100);
		order.setCustomerId(custId);
		order.setLd(LocalDate.now());
		int orderId=(int) (Math.random()*100);
		custEntry.put(custId,new Customer(customer.getName(),customer.getAddress(),customer.getPhone()));
		IcecreamEntry.put(orderId, new IcecreamOrder (orderId,custId,order.getTotalPrice(),order.getFlavor(),order.getLd()) );
		
		return orderId;
	}

	@Override
	public IcecreamOrder getOrderDetails(int OrderId) {
		if (IcecreamEntry.containsKey(OrderId)) {
			System.out.println("Your order details are as follows: ");
			System.out.println("OrderId: " + OrderId);
			System.out.println("Costumer Id" + IcecreamEntry.get(OrderId).getCustomerId());
			System.out.println("Topping Name: "+ IcecreamEntry.get(OrderId).getFlavor());
			System.out.println("Total Price: "+ IcecreamEntry.get(OrderId).getTotalPrice());
		
	}else{
		System.out.println("Invalid ID");}
		return null;
	}

	

	}
