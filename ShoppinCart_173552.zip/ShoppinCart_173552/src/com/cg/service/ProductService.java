/**
 * 
 */
package com.cg.service;

import java.util.TreeSet;

import com.cg.bean.Product;
import com.cg.exception.InvalidProductException;

/**This is the public interface of service
 * @author sbhujbal
 *@version1.0
 */
public interface ProductService {
	
	
	
	int addProduct(Product p);
	
	boolean removeProduct(int id) throws InvalidProductException;
	
	
	 TreeSet<Product>SortByName();
	 
	 
	 TreeSet<Product>SortByPrice();
	 

}
