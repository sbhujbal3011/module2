/**
 * 
 */
package com.cg.service;

import java.util.Comparator;
import java.util.TreeSet;

import com.cg.bean.Product;
import com.cg.dao.ProductDao;
import com.cg.dao.ProductDaoImpl;
import com.cg.exception.InvalidProductException;

/**
 * @author sbhujbal
 *
 */
public class ProductServiceImpl implements ProductService {
	
	private ProductDao dao;
	
	
	public ProductServiceImpl() {
		dao=new ProductDaoImpl();
	}

	/* (non-Javadoc)
	 * @see com.cg.service.ProductService#addProduct(com.cg.bean.Product)
	 */
	@Override
	public int addProduct(Product p) {
		int id=(int)(Math.random()*100);
		p.setId(id);
		dao.saveProduct(id, p);
		return id;
	}

	/* (non-Javadoc)
	 * @see com.cg.service.ProductService#removeProduct(int)
	 */
	@Override
	public boolean removeProduct(int id) throws InvalidProductException {
		
		return dao.deleteProduct(id);
	}

	/* (non-Javadoc)
	 * @see com.cg.service.ProductService#SortByName()
	 */
	@Override
	public TreeSet<Product> SortByName() {
		Comparator<Product> pc = (p1,p2) -> p1.getName().compareTo(p2.getName());
		
		TreeSet<Product>tree= new TreeSet<Product>(pc);
		tree.addAll(dao.getProducts());
		return tree;
	}

	/* (non-Javadoc)
	 * @see com.cg.service.ProductService#SortByPrice()
	 */
	@Override
	public TreeSet<Product> SortByPrice() {
		Comparator<Product> pc = (p1,p2) -> (int)(p1.getPrice()-p2.getPrice());
		TreeSet<Product>tree= new TreeSet<Product>(pc);
		tree.addAll(dao.getProducts());
		return tree;
		
	}

}
