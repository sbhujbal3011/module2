package com.cg.test;

/**
 * This class is the test class for Dao unit testing
 * 
 * @author sbhujbal
 *@version1.0
 */
public class TestProductDao {

}
