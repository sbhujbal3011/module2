package com.cg.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bean.Product;
import com.cg.service.ProductService;
import com.cg.service.ProductServiceImpl;

/**
 * This class is the test class for Service unit testing
 * 
 * @author sbhujbal
 *@version1.0
 */
public class TestProductService {
	
	private ProductService service;
	
	@Before
	public void init(){
		service=new ProductServiceImpl();
	}
	
	@Test
	public void testAddProduct(){
		Product p=new Product();
		p.setName("Iphone");
		p.setPrice(1000);
		service.addProduct(p);
	}
	
	@After
	public void flush(){
		service=null;
		
	}
	

}
