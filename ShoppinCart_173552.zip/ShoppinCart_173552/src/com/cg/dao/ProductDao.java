package com.cg.dao;

import java.util.Collection;
import java.util.List;
import java.util.TreeSet;

import com.cg.bean.Product;
import com.cg.exception.InvalidProductException;

/**
 * This is public interface of product Dao
 * @author sbhujbal
 *@version 1.0
 */
public interface ProductDao {
	
	/**
	 * Add product
	 * @param id
	 * @param p
	 * @return
	 */
	boolean saveProduct(int id,Product p);
	
	
	/**
	 * Delets a product
	 * @param id
	 * @return
	 * @throws InvalidProductException
	 */
	boolean deleteProduct(int id) throws InvalidProductException;
	
	/**
	 * Returns all product
	 * @return
	 */
	Collection<Product>getProducts();

}
