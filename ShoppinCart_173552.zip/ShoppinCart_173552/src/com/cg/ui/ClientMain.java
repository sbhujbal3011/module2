package com.cg.ui;

import java.util.Scanner;

import com.cg.bean.Product;
import com.cg.exception.InvalidProductException;
import com.cg.service.ProductServiceImpl;

public class ClientMain {
	public static void main(String[] args) {
		ProductServiceImpl service = new ProductServiceImpl();
		
		Scanner scan = new Scanner(System.in);
		String option;
		String Criteria;
		while (true) {
			System.out.println("Shopping Market");
			System.out
					.println("Enter your option:\n1.Add product \n2.Remove Product \n3.Sort Product");
			option = scan.next();

			if (option.equals("1")) {
				String name;
				double price;
				System.out.println("Enter name of product");
				name = scan.next();
				System.out.println("Enter price of product");
				price = scan.nextDouble();
				Product prod = new Product();
				prod.setName(name);
				prod.setPrice(price);
				int id = service.addProduct(prod);
				System.out.println("product added succeefully");
				System.out.println("Product id is" + id);

			} else if (option.equals("2")) {
				System.out.println("Enter ID of product YOU WANT TO DELETE");
				int id;
				id = scan.nextInt();
				System.out.println("deleted successfully");

				try {
					service.removeProduct(id);
				} catch (InvalidProductException e) {
					// TODO Auto-generated catch block
					System.out.println(e);
				}

			}

			else if (option.equals("3")) {
				System.out.println("Select sorting criteria\n" + "1. By name\n"
						+ "2. By Price\n");
				Criteria = scan.next();
				if (Criteria.equals("1")) {
					System.out.println("The sorted list by name is:");
					for (Product p : service.SortByName()) {
						System.out.println(p);
					}
				} else if (Criteria.equals("2")) {
					System.out.println("The sorted is by price is");
					for (Product p : service.SortByPrice()) {
						System.out.println(p);
					}
				} else {
					System.out.println("Enter valid choice");
				}

			}
		}
	}
}
