import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { EmployeeModel } from '../Model/Employee';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  //to create new employee or edit it
  @Input() employee :EmployeeModel
  constructor(private empService: EmployeeService) {
    this.employee=new EmployeeModel();
   }

  ngOnInit() {
  }
  add() {
    this.empService.add(this.employee);
    console.log(this.employee);
    this.employee = new EmployeeModel();
  }

}
