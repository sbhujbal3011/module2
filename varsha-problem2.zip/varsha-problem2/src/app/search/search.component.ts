import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../Model/Employee';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  employeeSearched: EmployeeModel;
  constructor(private empService:EmployeeService) { 
    this.employeeSearched = new EmployeeModel();
  }

  ngOnInit() {
  }

  searchemp(id:number)
  {
    this.employeeSearched = this.empService.searchemp(id);
  }
}
