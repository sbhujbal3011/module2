import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../Model/Employee';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-sort',
  templateUrl: './sort.component.html',
  styleUrls: ['./sort.component.css']
})
export class SortComponent implements OnInit {

  employeeArr:EmployeeModel[];
  isEditing:boolean;

  constructor(private empService:EmployeeService) { 
    this.employeeArr = [];
    
  }

  ngOnInit() {
    this.employeeArr = this.empService.getEmployees();
  }




   sortEmpById()
  {
    this.empService.sortEmpById();
  }
  sortEmpByName()
  {
    this.empService.sortEmpByName();
  }
  sortEmpBySalary()
  {
    this.empService.sortEmpBySalary();
  }

}

