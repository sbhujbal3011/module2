package UI;

import java.util.Scanner;

import Service.ServiceDao;
import Service.ServiceInterface;
import Bean.Customer;
import Bean.PizzaOrder;

public class MainUi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		ServiceInterface service = new ServiceDao();
		Customer customer = new Customer();
		PizzaOrder order = new PizzaOrder();
		int option, orderId, ch;
		String name, address, phone;
		System.out.println("Welcome to Eatpizza");
		System.out.println("select one option from following:");
		while (true) {
			System.out.println("1. Place order 2.\nDisplay Order 3.\nExit");
			option = sc.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter your name: ");
				name = sc.next();
				System.out.println("Enter your address: ");
				address = sc.next();
				System.out.println("Enter your 10 digit mobile no: ");
				phone = sc.next();
				customer.setName(name);
				customer.setAddress(address);
				customer.setPhone(phone);
				System.out.println("Select Toppings..");
				System.out.println("Pizza Toppings\tPrice");
				System.out.println("1.Capsicum\t30");
				System.out.println("2.Mashroom\t50");
				System.out.println("3.Jalpeno\t70");
				System.out.println("4.Panner\t85");
				ch = sc.nextInt();
				switch (ch) {
				case 1:
					order.setTopingName("Capsicum");
					order.setTotalPrice(350 + 30);

					break;
				case 2:
					order.setTopingName("MAshroom");
					order.setTotalPrice(350 + 50);

					break;
				case 3:
					order.setTopingName("Jalpeno");
					order.setTotalPrice(350 + 70);

					break;
				case 4:
					order.setTopingName("Paneer");
					order.setTotalPrice(350 + 85);

					break;

				default:
					System.out.println("Invalid input");
					break;
				}

				orderId = service.placeOrder(customer, order);
				System.out.println("Pizza Order palced with order id: "
						+ orderId);
				System.out.println("Order Date: " + order.getLd());
				System.out.println("Your Bill:" + order.getTotalPrice());
				break;
			case 2:
				System.out.println("Enter your OrderId: ");
				orderId = sc.nextInt();
				try {
					service.getOrderDetails(orderId);
				} catch (IDException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			
			case 3:
				System.out.println("thank you for your time");
				System.exit(0);

			default:
				break;
			}

		}
	}

}
