package Service;

import UI.IDException;
import Bean.Customer;
import Bean.PizzaOrder;
import Dao.PizzaDaoImpl;
import Dao.PizzaDaoInterface;

public class ServiceDao implements ServiceInterface {

	PizzaDaoInterface pizza=new PizzaDaoImpl();
	@Override
	public PizzaOrder getOrderDetails(int orderId) throws IDException {
		return pizza.getOrderDetails(orderId);
	}

	@Override
	public int placeOrder(Customer customer, PizzaOrder order) {
		return pizza.placeOrder(customer, order);
	}

}
