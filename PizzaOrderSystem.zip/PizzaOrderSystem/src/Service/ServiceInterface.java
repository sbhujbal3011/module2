package Service;

import UI.IDException;
import Bean.Customer;
import Bean.PizzaOrder;

public interface ServiceInterface {
	
	public PizzaOrder getOrderDetails(int orderId) throws IDException;
	public int placeOrder(Customer customer,PizzaOrder order);

}
