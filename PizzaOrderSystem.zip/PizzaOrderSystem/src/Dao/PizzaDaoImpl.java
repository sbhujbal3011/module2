package Dao;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import UI.IDException;
import Bean.Customer;
import Bean.PizzaOrder;

public class PizzaDaoImpl implements PizzaDaoInterface {
	Map<Integer, Customer> custEntry=new HashMap<Integer, Customer>();
	Map<Integer, PizzaOrder> pizzaEntry=new HashMap<Integer,PizzaOrder>();
	

	@Override
	public PizzaOrder getOrderDetails(int orderId) throws IDException {
		if (pizzaEntry.containsKey(orderId)) {
			System.out.println("Your order details are as follows: ");
			System.out.println("OrderId: " + orderId);
			System.out.println("Costumer Id" + pizzaEntry.get(orderId).getCustomerId());
			System.out.println("Topping Name: "+ pizzaEntry.get(orderId).getTopingName());
			System.out.println("Total Price: "+ pizzaEntry.get(orderId).getTotalPrice());
			
		}else {
			throw new IDException("id not found");
			//System.out.println("ID not found....");
		}
		return null;
	}

	@Override
	public int placeOrder(Customer customer, PizzaOrder order) {
		int custId=(int) (Math.random()*100);
		order.setCustomerId(custId);
		order.setLd(LocalDate.now());
		int orderId=(int) (Math.random()*100);
		custEntry.put(custId,new Customer(customer.getName(),customer.getAddress(),customer.getPhone()));
		pizzaEntry.put(orderId, new PizzaOrder(orderId,custId,order.getTotalPrice(),order.getTopingName(),order.getLd()) );
		
		return orderId;
	}

}
