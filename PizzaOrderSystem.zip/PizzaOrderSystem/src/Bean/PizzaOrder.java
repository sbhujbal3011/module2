package Bean;

import java.time.LocalDate;

public class PizzaOrder {

	private int OrderId,customerId;
	private double totalPrice;
	private String topingName;
	private LocalDate ld;
	public int getOrderId() {
		return OrderId;
	}
	public void setOrderId(int orderId) {
		OrderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getTopingName() {
		return topingName;
	}
	public void setTopingName(String topingName) {
		this.topingName = topingName;
	}
	public LocalDate getLd() {
		return ld;
	}
	public void setLd(LocalDate ld) {
		this.ld = ld;
	}
	
	public PizzaOrder() {
		super();
	}
	public PizzaOrder(int orderId, int customerId, double totalPrice,
			String topingName, LocalDate ld) {
		super();
		OrderId = orderId;
		this.customerId = customerId;
		this.totalPrice = totalPrice;
		this.topingName = topingName;
		this.ld = ld;
	}
	@Override
	public String toString() {
		return "PizzaOrder [OrderId=" + OrderId + ", customerId=" + customerId
				+ ", totalPrice=" + totalPrice + ", topingName=" + topingName
				+ ", ld=" + ld + "]";
	}
	
}
