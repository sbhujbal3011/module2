package com.cg.employee.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.employee.dto.Employee;



public class util {
	private static Map<Integer,Employee> EmployeeEntries = new HashMap<Integer,Employee>();

	public static Map<Integer,Employee>getEmployeeEntries(){
		EmployeeEntries.put(101, new Employee(101,"shreya",12000,"account"));
		EmployeeEntries.put(102, new Employee(102,"varsha",10000,"hr"));
		EmployeeEntries.put(103, new Employee(103,"rutuja",23000,"qc"));
		EmployeeEntries.put(104, new Employee(104,"yash",10000,"L and d"));
		
		return EmployeeEntries;
		
	}

}
