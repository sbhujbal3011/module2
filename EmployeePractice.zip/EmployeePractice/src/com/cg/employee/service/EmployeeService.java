package com.cg.employee.service;

import java.util.List;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.IdNotFoundException;


public class EmployeeService implements EmployeeServiceI {
	EmployeeDao dao = new EmployeeDao();

	@Override
	public List<Employee> getEmployeeList() {
		return dao.getEmployeeList();
	}

	@Override
	public List SortList(int criteria) {
		
		return dao.SortList(criteria);
	}

	

	@Override
	public void deleteEmployee(int EmpId) throws IdNotFoundException {
		 dao.deleteEmployee(EmpId);
		
	}

	
	

	
}
