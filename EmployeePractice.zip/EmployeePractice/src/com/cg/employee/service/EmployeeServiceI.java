package com.cg.employee.service;

import java.util.List;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.IdNotFoundException;

public interface EmployeeServiceI {
	public List<Employee>getEmployeeList();
	public void deleteEmployee(int EmpId) throws IdNotFoundException;
	public List<Employee>SortList(int criteria);
	

}
