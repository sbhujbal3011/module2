package com.cg.employee.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.IdNotFoundException;
import com.cg.employee.service.EmployeeService;



public class Main {
	public static void main(String[] args) {
	int criteria;
	int id;
	int EmpId=0 ;
		String choice;
	Scanner scan = new Scanner(System.in);
	System.out.println("Welcome to ERP");
while(true){
	while(true){
	EmployeeService service = new EmployeeService();
	List<Employee> arr=(List<Employee>) service.getEmployeeList();
	for (Employee emp : arr) {
		System.out.println(emp+ "\n");
	}
	/*System.out.println(service.getEmployeeList());*/
	System.out.println("What operation do you want to perform ?\n"
			+ "1.Sorting\n"
			+ "2.Delete\n"
			+ "3.Exit");
	System.out.println("Select a choice");
	choice = scan.next();
	if(choice.equals("1")){
		System.out.println("Select sorting criteria\n"
				+ "1. Employee name\n"
				+ "2. Employee Id\n"
				+ "3. Employee salary");
		criteria = scan.nextInt();	
		System.out.println("The sorted list is \n"+ service.SortList(criteria));
	
		break;
	}
	else if(choice.equals("2")){
		System.out.println("Please enter the mobile Id.");
		EmpId= scan.nextInt();
		try {
			service.deleteEmployee(EmpId);
			System.out.println("Delete Successfully");
		} catch (IdNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println();
	
		break;
	}else if(choice.equals("3")){
		System.exit(0);
		
	}}
}
}}