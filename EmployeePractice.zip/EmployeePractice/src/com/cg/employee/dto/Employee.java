package com.cg.employee.dto;

import java.util.Comparator;

public class Employee implements Comparator<Employee> {
	private int Id;
	private String name;
	private double salary;
	private String dept;
	public Employee() {
		super();
		
	}
	public Employee(int empId, String name, double salary, String dept) {
		super();
		this.Id = empId;
		this.name = name;
		this.salary = salary;
		this.dept = dept;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + Id + ", name=" + name + ", salary="
				+ salary + ", dept=" + dept + "]";
	}
	public int getEmpId() {
		return Id;
	}
	public void setEmpId(int empId) {
		this.Id = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Employee)
		{
			return ((Employee)obj).Id==this.Id;
		}
		return false;
	}
	@Override
	public int compare(Employee arg0, Employee arg1) {
		
		return arg0.getEmpId() - arg1.getEmpId();
	}
	

}
