package com.cg.employee.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.IdNotFoundException;
import com.cg.employee.util.util;

public class EmployeeDao implements EmployeeDaoI {
	Map<Integer, Employee> map = new HashMap<Integer, Employee>(
			util.getEmployeeEntries());
	
	ArrayList<Employee> set = new ArrayList<>(map.values());


	@Override
	public List<Employee> getEmployeeList() {
		List<Employee> emp = new ArrayList<>();
		for (Employee emps : set) {
			emp.add(emps);
		}
		return emp;

	}



 @Override
	public List SortList(int criteria) {
		if (criteria == 1)
			Collections.sort(set,
					(obj1, obj2) -> obj1.getName().compareTo(obj2.getName()));
		else if (criteria == 2)
			Collections
			.sort(set, (obj1, obj2) -> (int) (obj1.getEmpId() - (obj2
					.getEmpId())));
		else if (criteria == 3)
			
			Collections
					.sort(set, (obj1, obj2) -> (int)(obj1. getSalary() - (obj2
							.getSalary())));
		return set;
		
	}




	public void deleteEmployee(int EmpId) throws IdNotFoundException {
		set.remove(new Employee(EmpId, null, 0, null));
		if (util.getEmployeeEntries().containsKey(EmpId)) {
			System.out.println("ID Found");
		}
		else{
			throw new IdNotFoundException("Id not found");
			
		}
		
		
		
	}

}
