package com.cg.employee.dao;

import java.util.List;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.IdNotFoundException;



public interface EmployeeDaoI {
	List<Employee>getEmployeeList();
	void deleteEmployee(int empId) throws IdNotFoundException;
	public List<Employee>SortList(int criteria);

	//List SortList(int criteria);

}
